from flask import Flask, request, render_template, redirect, url_for, session
import os
import random
from werkzeug.utils import secure_filename
import PyPDF2
from transformers import T5Tokenizer, T5ForConditionalGeneration

from nltk.tokenize import sent_tokenize
import nltk
import spacy
from nltk.corpus import stopwords

# Load NLP models
model_name = "t5-small"
tokenizer = T5Tokenizer.from_pretrained(model_name)
model = T5ForConditionalGeneration.from_pretrained(model_name)
nlp = spacy.load('en_core_web_sm')

nltk.download('punkt')
nltk.download('stopwords')

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Replace with a strong secret key
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

ALLOWED_EXTENSIONS = {'pdf'}

# Function to check if the file is a valid PDF
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Preprocessing function
def preprocess_text(text):
    stop_words = set(stopwords.words("english"))
    doc = nlp(text)
    sentences = [sent.text.strip() for sent in doc.sents if len(sent.text.strip()) > 0]
    cleaned_sentences = []

    for sentence in sentences:
        words = [word.text for word in nlp(sentence) if not word.is_stop]
        cleaned_sentence = " ".join(words)
        cleaned_sentences.append(cleaned_sentence)

    return cleaned_sentences

# Function to extract text from PDF
def extract_text_from_pdf(file_path):
    text = ""
    with open(file_path, 'rb') as file:
        reader = PyPDF2.PdfReader(file)
        try:
            for page in reader.pages:
                text += page.extract_text() or ""  # Handle None cases
        except Exception as e:
            return "Error extracting text: " + str(e)
    return text

# Function to summarize text
def summarize_text(text):
    max_input_length = 512  # T5 can process 512 tokens at a time
    sentences = sent_tokenize(text)

    chunks = []
    current_chunk = ""

    # Split long text into smaller chunks
    for sentence in sentences:
        if len(tokenizer.encode(current_chunk + sentence)) < max_input_length:
            current_chunk += " " + sentence
        else:
            chunks.append(current_chunk.strip())
            current_chunk = sentence

    if current_chunk:
        chunks.append(current_chunk.strip())

    summarized_text = []

    # Summarize each chunk
    for chunk in chunks:
        input_ids = tokenizer.encode("summarize: " + chunk, return_tensors="pt", max_length=512, truncation=True)
        summary_ids = model.generate(input_ids, max_length=150, min_length=50, length_penalty=0.8, do_sample=False)
        summary = tokenizer.decode(summary_ids[0], skip_special_tokens=True)
        summarized_text.append(summary)

    return " ".join(summarized_text)  # Combine all summaries

# Function to generate multiple-choice questions
def generate_mcqs(text):
    cleaned_text = preprocess_text(text)  # Preprocess the text
    sentences = sent_tokenize(' '.join(cleaned_text))
    questions = []

    for sentence in sentences[:5]:  # Generate up to 5 questions
        doc = nlp(sentence)

        # Find nouns or proper nouns to replace with a blank
        noun_phrases = [chunk.text for chunk in doc.noun_chunks]
        if not noun_phrases:
            continue  # Skip sentences with no noun phrases
        correct_answer = random.choice(noun_phrases)  # Choose a noun phrase

        # Replace the chosen noun with a blank
        question_text = sentence.replace(correct_answer, '____')

        # Create options with the correct answer
        words_in_sentence = [token.text for token in doc if token.pos_ in ['NOUN', 'PROPN']]
        options = random.sample(words_in_sentence, min(3, len(words_in_sentence)))
        if correct_answer not in options:
            options.append(correct_answer)
        random.shuffle(options)  # Shuffle the options

        questions.append({
            'question': question_text,
            'options': options,
            'answer': correct_answer
        })

    return questions

# Route to upload a file
@app.route('/', methods=['GET', 'POST'])
def upload_file():
    session.clear()  # Clear previous session data
    if request.method == 'POST':
        if 'file' not in request.files:
            return "No file part"
        file = request.files['file']
        if file.filename == '':
            return "No selected file"
        if not allowed_file(file.filename):
            return "Invalid file type. Please upload a PDF."
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        return redirect(url_for('options', file_path=file_path))
    return render_template('upload.html')

# Route for options page
@app.route('/options')
def options():
    file_path = request.args.get('file_path')
    if not file_path or not os.path.exists(file_path):
        return "Invalid file path. Please upload a file again."
    return render_template('options.html', file_path=file_path)

# Route for text summarization
@app.route('/summarizer')
def summarizer():
    file_path = request.args.get('file_path')
    if not file_path or not os.path.exists(file_path):
        return "Invalid file path. Please upload a file again."

    text = extract_text_from_pdf(file_path)  # Extract text from PDF
    summary = summarize_text(text)  # Call summarize_text with the extracted text

    return render_template('summary.html', summary=summary)

# Route for quiz
@app.route('/quiz', methods=['GET', 'POST'])
def quiz():
    if 'questions' not in session:
        file_path = request.args.get('file_path')
        if not file_path or not os.path.exists(file_path):
            return "Invalid file path. Please upload a file again."
        text = extract_text_from_pdf(file_path)
        questions = generate_mcqs(text)
        session['questions'] = questions  # Store questions in session
    else:
        questions = session['questions']

    question_index = request.form.get('question_index', type=int)
    selected_option = request.form.get('selected_option')
    correct_answer = None
    is_correct = None

    if question_index is not None and 0 <= question_index < len(questions):
        question = questions[question_index]
        correct_answer = question['answer']
        is_correct = (selected_option == correct_answer)

    return render_template(
        'quiz.html',
        questions=questions,
        question_index=question_index,
        selected_option=selected_option,
        is_correct=is_correct,
        correct_answer=correct_answer,
        enumerate=enumerate  # Pass `enumerate` to the template
    )

if __name__ == '__main__':
    app.run(debug=True)
